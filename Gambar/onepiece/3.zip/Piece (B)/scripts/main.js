import { world } from "mojang-minecraft"

world.events.entityHurt.subscribe(function (event) {
    const damage = event.damage
    const hurtEntity = event.hurtEntity
    const entity = world.getDimension("overworld").spawnEntity("wesl3y:health", hurtEntity.location)
    entity.nameTag = `§c${damage}`
})

function capitalise(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

world.events.tick.subscribe(() => {
    const entities = Array.from(world.getDimension("overworld").getEntities())
    for (const entity of entities) {
        const health = entity.getComponent("health");
        if (health.current > 2) {
            entity.nameTag = capitalise(entity.id.split(":")[1].replace('_', ' ')) + "\n§l§a" + Math.round(health.current) + "§r/§l§a" + health.value;
        }
        if (health.current < 2) {
            entity.nameTag = capitalise(entity.id.split(":")[1].replace('_', ' '));
        }
    }
})