import { world } from "mojang-minecraft";
import { ActionFormData, ModalFormData } from "mojang-minecraft-ui";

const formZukanMenu = new ActionFormData()
                        .title("Akuma no Mi Encyclopedia")
                        .button("Hie Hie no Mi", "textures/items/hiehie/devilFruit_hiehie")
                        .button("Goro Goro no Mi", "textures/items/gorogoro/devilFruit_gorogoro")
                        .button("Pika Pika no Mi", "textures/items/pikapika/devilFruit_pikapika")
                        .button("Suna Suna no Mi", "textures/items/sunasuna/devilFruit_sunasuna")
                        .button("Gura Gura no Mi", "textures/items/guragura/devilFruit_guragura")
                        .button("Zushi Zushi no Mi", "textures/items/zusizusi/devilFruit_zusizusi")
                        .button("Ope Ope no Mi", "textures/items/opeope/devilFruit_opeope")
                        .button("Mera Mera no Mi", "textures/items/meramera/devilFruit_meramera")
                        .button("Yami Yami no Mi", "textures/items/yamiyami/devilFruit_yamiyami")
                        .button("Magu Magu no Mi", "textures/items/magmag/devilFruit_magmag")
                        .button("Tori Tori no Mi model Phoenix", "textures/items/toritori/devilFruit_toritori")
                        .button("Ito Ito no Mi", "textures/items/itoito/devilFruit_itoito")
                        .button("Soru Soru no Mi", "textures/items/sorusoru/devilFruit_sorusoru")
                        .button("Gomu Gomu no Mi", "textures/items/gomgom/devilFruit_gomgom")
                        .button("Hobi Hobi no Mi", "textures/items/hobihobi/devilFruit_hobihobi")
                        .button("Beta Beta no Mi", "textures/items/betabeta/devilFruit_betabeta")
                        .button("Wara Wara no Mi", "textures/items/warawara/devilFruit_warawara")
                        .button("Mochi Mochi no Mi", "textures/items/mochimochi/devilFruit_mochimochi")
                        .button("Uo Uo no Mi model Dragon", "textures/items/uouo/devilFruit_uouo")
                        .button("Yomi Yomi no Mi", "textures/items/yomiyomi/devilFruit_yomiyomi")
                        .button("Hito Hito no Mi", "textures/items/hitohito/devilFruit_hitohito")
                        .button("Hana Hana no Mi", "textures/items/hanahana/devilFruit_hanahana")
                        .button("Suke Suke no Mi", "textures/items/sukesuke/devilFruit_sukesuke")
                        .button("Noro Noro no Mi", "textures/items/noronoro/devilFruit_noronoro")
                        .button("Shiro Shiro no Mi", "textures/items/sirosiro/devilFruit_sirosiro")
                        .button("Bari Bari no Mi", "textures/items/baribari/devilFruit_baribari")
                        .button("Moku Moku no Mi", "textures/items/mokumoku/devilFruit_mokumoku")
                        .button("Doku Doku no Mi", "textures/items/dokudoku/devilFruit_dokudoku")
                        .button("Hito Hito no Mi model Daibutsu", "textures/items/hitohito/devilFruit_hitohito2")
                        .button("Jiki Jiki no Mi", "textures/items/jikijiki/devilFruit_jikijiki")
                        .button("Nikyu Nikyu no Mi", "textures/items/nikyunikyu/devilFruit_nikyunikyu")
                        .button("Raki Raki no Mi", "textures/items/rakiraki/devilFruit_rakiraki")
                        .button("Goru Goru no Mi", "textures/items/gorugoru/devilFruit_gorugoru");
						
const formMoneyMenu = new ModalFormData()
                        .title("withdraw money")
                        .slider("10", 0, 90, 10)
                        .slider("100", 0, 900, 100)
                        .slider("1000", 0, 9000, 1000)
                        .slider("10000", 0, 90000, 10000)
                        .slider("100000", 0, 900000, 100000)
                        .slider("1000000", 0, 9000000, 1000000)
                        .slider("10000000", 0, 90000000, 10000000)
                        .slider("100000000", 0, 900000000, 100000000);

world.events.beforeItemUse.subscribe(eventData => {
	const player = eventData.source;
	const playerName = player.nameTag;
	const itemId = eventData.item.id;
	if (itemId != "op_asa:status" && itemId != "op_asa:zukan" && itemId != "op_asa:money10" && itemId != "op_asa:money100" && itemId != "op_asa:money1000" && itemId != "op_asa:money10000" && itemId != "op_asa:money100000" && itemId != "op_asa:money1000000" && itemId != "op_asa:money10000000" && itemId != "op_asa:money100000000") {
		return;
	}
	if (itemId == "op_asa:status") {
        /** @type {EntityVariantComponent}  */
		const playerVariant = player.getComponent("minecraft:variant");
		const playerVariantValu = playerVariant.value;
		const playerVariantValuString = String(playerVariantValu);
		const playerVariantValuStringName = playerVariantValuString
			.replace('2700', '非能力者 no ability')
			.replace('2701', 'ヒエヒエの実 Hie Hie no Mi')
			.replace('27021', 'ゴロゴロの実 Goro Goro no Mi')
			.replace('2702', 'ゴロゴロの実 Goro Goro no Mi')
			.replace('2703', 'ピカピカの実 Pika Pika no Mi')
			.replace('2704', 'スナスナの実 Suna Suna no Mi')
			.replace('2705', 'グラグラの実 Gura Gura no Mi')
			.replace('2706', 'ズシズシの実 Zushi Zushi no Mi')
			.replace('2707', 'オペオペの実 Ope Ope no Mi')
			.replace('2708', 'メラメラの実 Mera Mera no Mi')
			.replace('2709', 'ヤミヤミの実 Yami Yami no Mi')
			.replace('2710', 'マグマグの実 Magu Magu no Mi')
			.replace('27112', 'トリトリの実 幻獣種 モデル 不死鳥 Tori Tori no Mi model Phoenix"')
			.replace('2711', 'トリトリの実 幻獣種 モデル 不死鳥 Tori Tori no Mi model Phoenix')
			.replace('2712', 'イトイトの実 Ito Ito no Mi')
			.replace('2713', 'ソルソルの実 Soru Soru no Mi')
			.replace('2714', 'ゴムゴムの実 Gomu Gomu no Mi')
			.replace('27140', 'ゴムゴムの実 Gomu Gomu no Mi')
			.replace('27141', 'ゴムゴムの実 Gomu Gomu no Mi')
			.replace('27143', 'ゴムゴムの実 Gomu Gomu no Mi')
			.replace('2715', 'ヤミヤミの実 × グラグラの実 Yami Yami no Mi × Gura no Mi')
			.replace('2716', 'ホビホビの実 Hobi Hobi no Mi')
			.replace('2717', 'ベタベタの実 Beta Beta no Mi')
			.replace('2718', 'ワラワラの実 Wara Wara no Mi')
			.replace('27181', 'ワラワラの実 Wara Wara no Mi')
			.replace('2719', 'モチモチの実 Mochi Mochi no Mi')
			.replace('272011', 'ウオウオの実 幻獣種 モデル 青龍 Uo Uo no Mi model Dragon')
			.replace('27201', 'ウオウオの実 幻獣種 モデル 青龍 Uo Uo no Mi model Dragon')
			.replace('2720', 'ウオウオの実 幻獣種 モデル 青龍 Uo Uo no Mi model Dragon')
			.replace('27210', 'ヨミヨミの実 Yomi Yomi no Mi')
			.replace('27211', 'ヨミヨミの実 Yomi Yomi no Mi')
			.replace('2721', 'ヨミヨミの実 Yomi Yomi no Mi')
			.replace('2722', 'ヒトヒトの実 Hito Hito no Mi')
			.replace('2723', 'ハナハナの実 Hana Hana no Mi')
			.replace('2724', 'スケスケの実 Suke Suke no Mi')
			.replace('2725', 'ノロノロの実 Noro Noro no Mi')
			.replace('2726', 'シロシロの実 Shiro Shiro no Mi')
			.replace('2727', 'バリバリの実 Bari Bari no Mi')
			.replace('2729', 'モクモクの実 Moku Moku no Mi')
			.replace('2730', 'ドクドクの実 Doku Doku no Mi')
			.replace('27301', 'ドクドクの実 Doku Doku no Mi')
			.replace('273011', 'ドクドクの実 Doku Doku no Mi')
			.replace('273111', 'ヒトヒトの実 幻獣種 モデル 大仏 Hito Hito no Mi model Daibutsu')
			.replace('27311', 'ヒトヒトの実 幻獣種 モデル 大仏 Hito Hito no Mi model Daibutsu')
			.replace('2731', 'ヒトヒトの実 幻獣種 モデル 大仏 Hito Hito no Mi model Daibutsu')
			.replace('2732', 'ジキジキの実 Jiki Jiki no Mi')
			.replace('2733', 'ニキュニキュの実 Nikyu Nikyu no Mi')
			.replace('2734', 'ラキラキの実 Raki Raki no Mi')
			.replace('2735', 'ゴルゴルの実 Goru Goru no Mi');
		const playerScoreAll = world.scoreboard.getParticipants();
		for (const playerScore of playerScoreAll) {
			const playerScoreName = playerScore.displayName;
			if (playerScoreName == playerName) {
				const playerHp = world.scoreboard.getObjective("hp");
				const playerHpScore = playerHp.getScore(playerScore);
				const playerBounty1 = world.scoreboard.getObjective("bounty1");
				const playerBounty1Score = playerBounty1.getScore(playerScore);
				const playerBounty2 = world.scoreboard.getObjective("bounty2");
				const playerBounty2Score = playerBounty2.getScore(playerScore);
				const playerBountyScore = (String(playerBounty1Score + playerBounty2Score * 100000000)).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1,');
				const playerHaki = world.scoreboard.getObjective("haki");
				const playerHakiScore = playerHaki.getScore(playerScore);
				const playerMoney1 = world.scoreboard.getObjective("money1");
				const playerMoney1Score = playerMoney1.getScore(playerScore);
				const playerMoney2 = world.scoreboard.getObjective("money2");
				const playerMoney2Score = playerMoney2.getScore(playerScore);
				const playerMoneyScore = playerMoney1Score + playerMoney2Score * 100000000;
				const playerMoneyScoreString = (String(playerMoneyScore)).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1,');
				const playerStatus = world.scoreboard.getObjective("status");
				const playerStatusScore = playerStatus.getScore(playerScore);
				const playerStatusScoreString = String(playerStatusScore);
				const playerStatusScoreStringName = playerStatusScoreString
					.replace('70', '＊市民＊')
					.replace('10', '＊海賊見習い Apprentice＊')
					.replace('20', '＊ルーキー Rookie＊')
					.replace('30', '＊新世界のルーキー Rookie in the New World＊')
					.replace('40', '＊王下七武海 Oka shichibukai＊')
					.replace('50', '＊四皇 Yonko＊')
					.replace('60', '＊海賊王 King of the Pirates＊')
					.replace('11', '＊新兵 Recruit＊')
					.replace('12', '＊海軍本部少尉 Lieutenant＊')
					.replace('13', '＊海軍本部大佐 Captain＊')
					.replace('14', '＊海軍本部中将 Vice Admiral＊')
					.replace('15', '＊海軍本部大将 Admiral＊')
					.replace('16', '＊海軍本部元帥 Fleet Admiral＊');
				const statusMenu = new ActionFormData()
                                    .title("ステータス")
                                    .body(`${playerStatusScoreStringName}\n${playerName}\n${playerVariantValuStringName}\n--------------------------------\n懸賞金Bounty  :  ${playerBountyScore}\n体力HP  :  ${playerHpScore}\n覇気Haki  :  ${playerHakiScore}\n所持金Money  :  ${playerMoneyScoreString}\n--------------------------------\n\n\n\n`)
                                    .button("withdraw money");
				statusMenu.show(player).then(response => {
					if (response.selection === 0) {
						formMoneyMenu.show(player).then(result => {
							const money10 = parseInt(result.formValues[0]);
							const moneyPlace10 = money10 / 10;
							const money100 = parseInt(result.formValues[1]);
							const moneyPlace100 = money100 / 100;
							const money1000 = parseInt(result.formValues[2]);
							const moneyPlace1000 = money1000 / 1000;
							const money10000 = parseInt(result.formValues[3]);
							const moneyPlace10000 = money10000 / 10000;
							const money100000 = parseInt(result.formValues[4]);
							const moneyPlace100000 = money100000 / 100000;
							const money1000000 = parseInt(result.formValues[5]);
							const moneyPlace1000000 = money1000000 / 1000000;
							const money10000000 = parseInt(result.formValues[6]);
							const moneyPlace10000000 = money10000000 / 10000000;
							const money100000000 = parseInt(result.formValues[7]);
							const moneyPlace100000000 = money100000000 / 100000000;
							const moneyTotal = money10 + money100 + money1000 + money10000 + money100000 + money1000000 + money10000000 + money100000000;
							const money1Total = money10 + money100 + money1000 + money10000 + money100000 + money1000000 + money10000000;
							const money2Total = moneyPlace100000000;
							if (moneyTotal > playerMoneyScore) {
								player.runCommand(`tellraw @s {"rawtext":[{"translate":"rawtext.noMoney"}]}`);
								return;
							}
							player.runCommand(`scoreboard players remove @s money1 ${money1Total}`);
							player.runCommand(`scoreboard players remove @s money2 ${money2Total}`);
							if (money10 > 0) {
								player.runCommand(`give @s op_asa:money10 ${moneyPlace10}`);
							}
							if (money100 > 0) {
								player.runCommand(`give @s op_asa:money100 ${moneyPlace100}`);
							}
							if (money1000 > 0) {
								player.runCommand(`give @s op_asa:money1000 ${moneyPlace1000}`);
							}
							if (money10000 > 0) {
								player.runCommand(`give @s op_asa:money10000 ${moneyPlace10000}`);
							}
							if (money100000 > 0) {
								player.runCommand(`give @s op_asa:money100000 ${moneyPlace100000}`);
							}
							if (money1000000 > 0) {
								player.runCommand(`give @s op_asa:money1000000 ${moneyPlace1000000}`);
							}
							if (money10000000 > 0) {
								player.runCommand(`give @s op_asa:money10000000 ${moneyPlace10000000}`);
							}
							if (money100000000 > 0) {
								player.runCommand(`give @s op_asa:money100000000 ${moneyPlace100000000}`);
							}
						})
					}
				});
			}
		}
	}
	if (itemId == "op_asa:zukan") {
		formZukanMenu.show(player).then(response => {
			if (response.selection === 0) {
				player.runCommand("give @s op_asa:devilFruit_hiehie");
			}
			if (response.selection === 1) {
				player.runCommand("give @s op_asa:devilFruit_gorogoro");
			}
			if (response.selection === 2) {
				player.runCommand("give @s op_asa:devilFruit_pikapika");
			}
			if (response.selection === 3) {
				player.runCommand("give @s op_asa:devilFruit_sunasuna");
			}
			if (response.selection === 4) {
				player.runCommand("give @s op_asa:devilFruit_guragura");
			}
			if (response.selection === 5) {
				player.runCommand("give @s op_asa:devilFruit_zusizusi");
			}
			if (response.selection === 6) {
				player.runCommand("give @s op_asa:devilFruit_opeope");
			}
			if (response.selection === 7) {
				player.runCommand("give @s op_asa:devilFruit_meramera");
			}
			if (response.selection === 8) {
				player.runCommand("give @s op_asa:devilFruit_yamiyami");
			}
			if (response.selection === 9) {
				player.runCommand("give @s op_asa:devilFruit_magmag");
			}
			if (response.selection === 10) {
				player.runCommand("give @s op_asa:devilFruit_toritori");
			}
			if (response.selection === 11) {
				player.runCommand("give @s op_asa:devilFruit_itoito");
			}
			if (response.selection === 12) {
				player.runCommand("give @s op_asa:devilFruit_sorusoru");
			}
			if (response.selection === 13) {
				player.runCommand("give @s op_asa:devilFruit_gomgom");
			}
			if (response.selection === 14) {
				player.runCommand("give @s op_asa:devilFruit_hobihobi");
			}
			if (response.selection === 15) {
				player.runCommand("give @s op_asa:devilFruit_betabeta");
			}
			if (response.selection === 16) {
				player.runCommand("give @s op_asa:devilFruit_warawara");
			}
			if (response.selection === 17) {
				player.runCommand("give @s op_asa:devilFruit_mochimochi");
			}
			if (response.selection === 18) {
				player.runCommand("give @s op_asa:devilFruit_uouo");
			}
			if (response.selection === 19) {
				player.runCommand("give @s op_asa:devilFruit_yomiyomi");
			}
			if (response.selection === 20) {
				player.runCommand("give @s op_asa:devilFruit_hitohito");
			}
			if (response.selection === 21) {
				player.runCommand("give @s op_asa:devilFruit_hanahana");
			}
			if (response.selection === 22) {
				player.runCommand("give @s op_asa:devilFruit_sukesuke");
			}
			if (response.selection === 23) {
				player.runCommand("give @s op_asa:devilFruit_noronoro");
			}
			if (response.selection === 24) {
				player.runCommand("give @s op_asa:devilFruit_sirosiro");
			}
			if (response.selection === 25) {
				player.runCommand("give @s op_asa:devilFruit_baribari");
			}
			if (response.selection === 26) {
				player.runCommand("give @s op_asa:devilFruit_mokumoku");
			}
			if (response.selection === 27) {
				player.runCommand("give @s op_asa:devilFruit_dokudoku");
			}
			if (response.selection === 28) {
				player.runCommand("give @s op_asa:devilFruit_hitohito2");
			}
			if (response.selection === 29) {
				player.runCommand("give @s op_asa:devilFruit_jikijiki");
			}
			if (response.selection === 30) {
				player.runCommand("give @s op_asa:devilFruit_nikyunikyu");
			}
			if (response.selection === 31) {
				player.runCommand("give @s op_asa:devilFruit_rakiraki");
			}
			if (response.selection === 32) {
				player.runCommand("give @s op_asa:devilFruit_gorugoru");
			}
		});
	}
	if (itemId == "op_asa:money10") {
		player.runCommand("scoreboard players add @s money1 10");
		player.runCommand("clear @s op_asa:money10 0 1");
	}
	if (itemId == "op_asa:money100") {
		player.runCommand("scoreboard players add @s money1 100");
		player.runCommand("clear @s op_asa:money100 0 1");
	}
	if (itemId == "op_asa:money1000") {
		player.runCommand("scoreboard players add @s money1 1000");
		player.runCommand("clear @s op_asa:money1000 0 1");
	}
	if (itemId == "op_asa:money10000") {
		player.runCommand("scoreboard players add @s money1 10000");
		player.runCommand("clear @s op_asa:money10000 0 1");
	}
	if (itemId == "op_asa:money100000") {
		player.runCommand("scoreboard players add @s money1 100000");
		player.runCommand("clear @s op_asa:money100000 0 1");
	}
	if (itemId == "op_asa:money1000000") {
		player.runCommand("scoreboard players add @s money1 1000000");
		player.runCommand("clear @s op_asa:money1000000 0 1");
	}
	if (itemId == "op_asa:money10000000") {
		player.runCommand("scoreboard players add @s money1 10000000");
		player.runCommand("clear @s op_asa:money10000000 0 1");
	}
	if (itemId == "op_asa:money100000000") {
		player.runCommand("scoreboard players add @s money2 1");
		player.runCommand("clear @s op_asa:money100000000 0 1");
	}
});